<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>My Education Foundation</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>
    
  <input type="hidden" name="base_url" id="base_url" value="<?php echo base_url();?>">
  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">
      <h1 class="logo me-auto"><a href="index.html">Logo goes here<span>.</span></a></h1>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <!-- .navbar -->

    </div>
</header>
<!-- End Header -->


<div class="container" style="margin-top:110px; width:65%; margin-bottom:30px;"> 
    <style type="text/css">
      #admission_form span,em{
        color:red;
      }
    </style>

    <form class="forms-sample" id="admission_form" action="<?php echo base_url('Admission_Data_Save');?>" method="POST" autocomplete="off" enctype="multipart/form-data"> 
      <?php if($this->session->flashdata('success')){ ?>
        <div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Success! </strong><?php echo $this->session->flashdata('success'); ?> </div>
      <?php }else if($this->session->flashdata('error')){  ?>
        <div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong> Danger! </strong><?php echo $this->session->flashdata('error'); ?></div>
      <?php } ?>

      <marquee> <span style="margin: 10px 0 10px 0; color:#e03a3c">" Admissions are open Now...! Hurry Up...!! "</span></marquee>
      <div class="form-group">
        <label for="studentFname">Student's First Name</label>
        <input type="text" class="form-control" id="studentFname" name="studentFname" value="<?php echo set_value('studentFname');?>" placeholder="Student's First Name">
        <?php echo form_error('studentFname');?>
      </div>

      <div class="form-group mt-3">
        <label for="studentLname">Student's Last Name</label>
        <input type="text" class="form-control" id="studentLname" name="studentLname" value="<?php echo set_value('studentLname');?>" placeholder="Student's Last Name">
        <?php echo form_error('studentLname');?>
      </div>

      <div class="form-group mt-3">
        <label for="studentDob">Student's Date Of Birth</label>
        <input type="text" class="form-control" id="studentDob" name="studentDob" value="<?php echo set_value('studentDob');?>" placeholder="Student's Date Of Birth">
        <?php echo form_error('studentDob');?>
      </div>

      <div class="form-group mt-3">
        <label for="parentName">Parent's Full Name</label>
        <input type="text" class="form-control" id="parentName" name="parentName" value="<?php echo set_value('parentName');?>" placeholder="Parent's Full Name">
        <?php echo form_error('parentName');?>
      </div>

      <div class="form-group mt-3 mb-3">
        <label>Class you want to apply for?</label>
        <select class="form-control" id="className" name="className">
            <option value="">Select Class</option>
            <option value="1st" <?php echo set_select('className',"1st", ( !empty($data) && $data == "1st" ? TRUE : FALSE )); ?>>First Standard</option>
            <option value="2nd" <?php echo set_select('className',"2nd", ( !empty($data) && $data == "2nd" ? TRUE : FALSE )); ?>>Second Standard</option>
            <option value="3rd" <?php echo set_select('className',"3rd", ( !empty($data) && $data == "3rd" ? TRUE : FALSE )); ?>>Third Standard</option>
            <option value="4th" <?php echo set_select('className',"4th", ( !empty($data) && $data == "4th" ? TRUE : FALSE )); ?>>Fourth Standard</option>
            <option value="5th" <?php echo set_select('className',"5th", ( !empty($data) && $data == "5th" ? TRUE : FALSE )); ?>>Fifth Standard</option>
            <option value="6th" <?php echo set_select('className',"6th", ( !empty($data) && $data == "6th" ? TRUE : FALSE )); ?>>Sixth Standard</option>
            <option value="7th" <?php echo set_select('className',"7th", ( !empty($data) && $data == "7th" ? TRUE : FALSE )); ?>>Seventh Standard</option>
            <option value="8th" <?php echo set_select('className',"8th", ( !empty($data) && $data == "8th" ? TRUE : FALSE )); ?>>Eighth Standard</option>
            <option value="9th" <?php echo set_select('className',"9th", ( !empty($data) && $data == "9th" ? TRUE : FALSE )); ?>>Nineth Standard</option>
            <option value="10th" <?php echo set_select('className',"10th", ( !empty($data) && $data == "10th" ? TRUE : FALSE )); ?>>Tenth Standard</option>
        </select>
        <?php echo form_error('className'); ?>
      </div>

      <div class="form-group mb-3">
        <label for="address">Address</label> <br>
        <textarea id="address" name="address" class="form-control" rows="3" cols="124"><?php echo set_value('address');?></textarea>
        <?php echo form_error('address');?>
      </div>

      <div class="form-group mb-3">
        <label for="city">City</label>
        <input type="text" class="form-control" id="city" name="city" placeholder="City" value="<?php echo set_value('city');?>">
        <?php echo form_error('city');?>
      </div>

      <div class="form-group mb-3">
        <label for="state">State</label>
        <input type="text" class="form-control" id="state" name="state" value="<?php echo set_value('state');?>" placeholder="State">
        <?php echo form_error('state');?>
      </div>

      <div class="form-group mb-3">
        <label for="pin">Pin Code</label>
        <input type="text" class="form-control" id="pin" name="pin" placeholder="Pin Code" value="<?php echo set_value('pin');?>">
        <?php echo form_error('pin');?>
      </div>

      <div class="form-group mb-3">
        <label for="country">Country</label>
        <input type="text" class="form-control" id="country" name="country" placeholder="Country" value="<?php echo set_value('country');?>">
        <?php echo form_error('country');?>
      </div>

      <div class="form-group mb-3">
        <label for="mobile">Contact Number</label>
        <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Contact Number" value="<?php echo set_value('mobile');?>">
        <?php echo form_error('mobile');?>
      </div>

      <div class="form-group mb-3">
        <label for="email">Email Id</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="Email Id" value="<?php echo set_value('email');?>">
        <?php echo form_error('email');?>
      </div>

      <div class="form-group">
        <label for="yes_no_fb">Do you want to request transportation services for the student?</label>
          <br>
          <input type="radio"  name="transportService" id="transportService" value="Yes"  <?php  echo set_value('transportService') == "Yes" ? "checked" : ""; ?> /> Yes &emsp;
          <input type="radio"  name="transportService" id="transportService" value="No" <?php echo set_value('transportService') == "No" ? "checked" : ""; ?> /> No    
          <?php echo form_error('transportService');?>
      </div>

      <center>
          <button type="submit" class="btn btn-primary" style="background-color:#e03a3c !important; border:none;">Submit Now</button>
      </center>
    </form>
</div>

<!-- ======= Footer ======= -->
<footer id="footer">

<div class="footer-top">
  <div class="container">
    <div class="row">

      <div class="col-lg-4 col-md-6 footer-contact">
        <h3>Logo<span>.</span></h3>
        <p>
          A108 Adam Street <br>
          New York, NY 535022<br>
          United States <br><br>
          <strong>Phone:</strong> +1 5589 55488 55<br>
          <strong>Email:</strong> info@example.com<br>
        </p>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Useful Links</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li> 
          <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
        </ul>
      </div>

      <div class="col-lg-5 col-md-6 footer-newsletter">
        <h4>Join Our Newsletter</h4>
        <p>Subscribe to get Notification</p>
        <form id="Newsletter_DB" method="post">
          <input type="email" name="Subscribe_Email" id="Subscribe_Email" >
          <input type="hidden" name="Subscribe_Client_Name" id="Subscribe_Client_Name" value="My Education Foundation">
          <input type="button" value="Subscribe" style="background-color:#e35052; color:white; border:none; padding:8px;" name="Newsletter_DB_Btn" id="Newsletter_DB_Btn">
        </form>
      </div>

    </div>
  </div>
</div>

<div class="container d-md-flex py-4">

  <div class="me-md-auto text-center text-md-start">
    <div class="copyright">
      &copy; Copyright <strong><span>My Education Foundation</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="#">My Education Foundation</a>
    </div>
  </div>
  <div class="social-links text-center text-md-end pt-3 pt-md-0">
    <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
    <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
    <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
    <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
    <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
  </div>
</div>
</footer>
<!-- End Footer -->

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="<?php echo base_url('assets/js/jquery-3.6.0.js');?>"></script>
<script src="<?php echo base_url('assets/vendor/purecounter/purecounter.js');?>"></script>
<script src="<?php echo base_url('assets/vendor/aos/aos.js');?>"></script>
<script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
<script src="<?php echo base_url('assets/vendor/glightbox/js/glightbox.min.js');?>"></script>
<script src="<?php echo base_url('assets/vendor/isotope-layout/isotope.pkgd.min.js');?>"></script>
<script src="<?php echo base_url('assets/vendor/swiper/swiper-bundle.min.js');?>"></script>
<script src="<?php echo base_url('assets/vendor/php-email-form/validate.js');?>"></script>

<!-- Template Main JS File -->
<script src="<?php echo base_url('assets/js/main.js');?>"></script>
<script src="<?php echo base_url('assets/js/MyLib.js');?>"></script>

</body>
</html>


