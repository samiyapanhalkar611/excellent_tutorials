<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Excellent Tutorials</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/excellent_favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <input type="hidden" name="base_url" id="base_url" value="<?php echo base_url();?>">

    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">
      <img src="<?php echo base_url('assets/img/excellent_tutorials_logo.png');?>" alt="Logo" height="150px" width="250px">
    
      <div class="sam" style="margin-left:200px;">
        <nav id="navbar" class="navbar order-last order-lg-0 ms-5">
          <ul>
            <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
            <li><a class="nav-link scrollto" href="#about">About</a></li>
            <li><a class="nav-link scrollto" href="#services">Services</a></li>
            <li><a class="nav-link scrollto " href="#portfolio">Portfolio</a></li>
            <li><a class="nav-link scrollto " href="#testimonials">testimonials</a></li>
            <li><a class="nav-link scrollto " href="#faq">FAQs</a></li>
            <li><a class="nav-link scrollto" href="#team">Team</a></li>
            <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          </ul>
          <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
        <!-- .navbar -->
      </div>
      <a href="#admission_open" class="get-started-btn scrollto">Admission</a>
    </div>
  </header><!-- End Header -->


  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container" data-aos="zoom-out" data-aos-delay="100">
      <div class="row">
        <div class="col-xl-6">
          <h1>Welcome to <span >Excellent Tutorials</span></h1>
          <h2>We are team of Experienced Teachers designing a Better Future.</h2>
          <a href="<?php echo base_url('Admission_Data_Save');?>" class="btn-get-started scrollto">Admissions Open</a>
        </div>
      </div>
    </div>

  </section>
  <!-- End Hero -->

  <main id="main">

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients">
      <div class="container" data-aos="zoom-in">

        <div class="clients-slider swiper">
          <div class="swiper-wrapper align-items-center">
            <div class="swiper-slide"><img src="assets/img/logos/Javascript_logo.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/logos/angular_logo.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/logos/nodeJS_logo.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/logos/MS_SQL_Server.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/logos/react_logo.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/logos/python.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/logos/C_Logo.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/logos/Asp.net_logo.png" class="img-fluid" alt=""></div>
          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section>
    <!-- End Clients Section -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about section-bg">
      <div class="container" data-aos="fade-up">

        <div class="row no-gutters">
          <div class="content col-xl-5 d-flex align-items-stretch">
            <div class="content">
              <h3>All type of Cources at one place!</h3>
              <p>
                We are Excellent Tutorials with talented and experienced teachers from around who have gathered together to mould students for their better future.
              </p>
              <a href="#tabs" class="learn-more-btn"><span>Learn-more</span> <i class="bx bx-chevron-right"></i></a>
            </div>
          </div>
          <div class="col-xl-7 d-flex align-items-stretch">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100">
                  <i class="bx bx-receipt"></i>
                  <h4>1<sup>st</sup> to 10<sup>th</sup> Standard</h4>
                  <p>We provide classes to 1<sup>st</sup> to 10<sup>th</sup> students. Fill the form to get Admission today.</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="200">
                  <i class="bx bx-cube-alt"></i>
                  <h4>Junior College (HSC)</h4>
                  <p>We educate Student of junior college and prepare them well for their HSC examinations.</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="300">
                  <i class="bx bx-images"></i>
                  <h4>Competative Exams</h4>
                  <p>We train students for their Exams like CET, NEET, JEE- Mains, Advance so that they can know their interest and choose their career properly.</p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="400">
                  <i class="bx bx-shield"></i>
                  <h4>Languages</h4>
                  <p>We teach computer languages like C, C++, Java, Python, JavaScript along with their franeworks like Angular, React, Node,ect.</p>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Tabs Section ======= -->
    <section id="tabs" class="tabs">
      <div class="container" data-aos="fade-up">

        <div class="tab-content">
          <div class="tab-pane active show" id="tab-1">
            <div class="row">
            <div class="section-title">
              <h2>About Us</h2>
            </div>
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0" data-aos="fade-up" data-aos-delay="100">
                <h3><span style="color:#d09d1b;"><b><i>Excellent Tutorials</i></b></span> is working towards a Better Future of the World.</h3>
                <p class="fst-italic">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam varius facilisis suscipit. Proin sit amet interdum odio, sit amet tincidunt velit. Donec non ullamcorper odio, non tincidunt ante. Donec dui felis, interdum sit amet neque cursus, rhoncus commodo nisl. 
                </p>
                <ul>
                  <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                  <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
                  <li><i class="ri-check-double-line"></i> Suspendisse lobortis enim blandit, trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.</li>
                </ul>
                <p>
                  Fusce orci nunc, bibendum quis libero et, aliquet commodo lacus. Suspendisse lobortis enim blandit, luctus velit et, facilisis sem. Curabitur felis lacus, facilisis sit amet tristique in, consequat ut diam. Cras at ullamcorper augue, ut venenatis velit. Nunc at varius nisl, vel cursus sem. Donec interdum ac turpis nec venenatis.
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="200">
                <img src="assets\img\Images\about_image.webp" alt="" class="img-fluid">
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
    <!-- End Tabs Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg ">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <p>Below are the Services that we provide for betterment.</p>
        </div>

        <div class="row">
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
              <i class="bi bi-card-checklist"></i>
              <h4>1<sup>st</sup> to 10<sup>th</sup> Standard</h4>
              <p>We provide classes to 1<sup>st</sup> to 10<sup>th</sup> students. Fill the form to get Admission today.</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
              <i class="bi bi-card-checklist"></i>
              <h4>Junior College (HSC)</h4>
              <p>We educate Student of junior college and prepare them well for their HSC examinations.</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="300">
              <i class="bi bi-bar-chart"></i>
              <h4>Competative Exams</h4>
              <p>We train students for their Exams like CET, NEET, JEE- Mains, Advance so that they can know their interest and choose their career properly.</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="400">
              <i class="bi bi-binoculars"></i>
              <h4>Computer Languages</h4>
              <p>We teach computer languages like C, C++, Java, Python, JavaScript along with their franeworks like Angular, React, Node,ect.</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="500">
              <i class="bi bi-brightness-high"></i>
              <h4>Classroom</h4>
              <p>We have neat and clean classroons with calm and peaceful atmosphere which allows student to study with more focus.</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="600">
              <i class="bi bi-calendar4-week"></i>
              <h4>Computer Labs</h4>
              <p>We have Computer Laboratories with fast internet connectins so that students can practice their work without any interruption.</p>
            </div>
          </div>
        </div>

      </div>
    </section>
    <!-- End Services Section -->

    <!-- Admission Section -->
      <section id="admission_open" class="admission_open admission-box">
        <div class="container admission_section">
          <div class="title_section">
          <div class="section-title">
            <h2 style="color: white;">Admission Form</h2>
          </div>
            <h5 class="text-center-white"><b>Note: </b>This form is applicable only for Admission of students from 1<sup>st</sup> to 10<sup>th</sup> Standard</h5>
            <p class="text-center-white">Click Below To Fill Admission Form</p>
          </div>

          <div class="section_btn text-center mb-3 mt-3">
            <button class="btn" >
              <a href="<?php echo base_url('Admission_Data_Save');?>" style="background-color:#d09d1b; color:white; border:none; padding:10px;">Fill Now</a> 
            </button><br><br>
            <div>
              <h4 class="text-center-white">To Apply for other Courses please contact us, Give a call on this Number -0233 232 5776 or Visit on the Address mentioned below.</h4>
            </div>

          </div>
        </div>
      </section>
    <!-- End Admission Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Portfolio</h2>
          <p>Glimpse of our Classes.</p>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url('assets/img/Images/img1.webp');?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Teaching</h4>
                <div class="portfolio-links">
                  <a href="<?php echo base_url('assets/img/Images/img1.webp');?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Teaching"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url('assets/img/Images/img2.webp');?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Doubt Solving Sessions</h4>
                <div class="portfolio-links">
                  <a href="<?php echo base_url('assets/img/Images/img2.webp');?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Doubt Solving Sessions"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url('assets/img/Images/img3.webp');?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Kids Classroom</h4>
                <div class="portfolio-links">
                  <a href="<?php echo base_url('assets/img/Images/img3.webp');?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Kids Classroom"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url('assets/img/Images/img4.webp');?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Kids Classroom</h4>
                <div class="portfolio-links">
                  <a href="<?php echo base_url('assets/img/Images/img4.webp');?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Kids Classroom"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url('assets/img/Images/img5.webp');?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Classroom</h4>
                <div class="portfolio-links">
                  <a href="<?php echo base_url('assets/img/Images/img5.webp');?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Classroom"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url('assets/img/Images/img6.webp');?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Kids Classroom</h4>
                <div class="portfolio-links">
                  <a href="<?php echo base_url('assets/img/Images/img6.webp');?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Kids Classroom"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url('assets/img/Images/img7.png');?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Activities</h4>
                <div class="portfolio-links">
                  <a href="<?php echo base_url('assets/img/Images/img7.png');?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Activities"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url('assets/img/Images/img8.webp');?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Computers</h4>
                <div class="portfolio-links">
                  <a href="<?php echo base_url('assets/img/Images/img8.webp');?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Computers"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="<?php echo base_url('assets/img/Images/img9.webp');?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4>Computer Lab</h4>
                <div class="portfolio-links">
                  <a href="<?php echo base_url('assets/img/Images/img9.webp');?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Computer Lab"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
    <!-- End Portfolio Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Testimonials</h2>
          <p>See what our Students say.</p>
        </div>

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
                  <h3>Saul Goodman</h3>
                  <h4>Ceo &amp; Founder</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
                  <h3>Sara Wilsson</h3>
                  <h4>Designer</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
                  <h3>Jena Karlis</h3>
                  <h4>Store Owner</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint minim.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
                  <h3>Matt Brandon</h3>
                  <h4>Freelancer</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
                  <h3>John Larson</h3>
                  <h4>Entrepreneur</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat esse veniam culpa fore nisi cillum quid.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Frequently Asked Questions</h2>
        </div>

        <ul class="faq-list accordion" data-aos="fade-up">

          <li>
            <a data-bs-toggle="collapse" class="collapsed" data-bs-target="#faq1">What is the admission procedure? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq1" class="collapse" data-bs-parent=".faq-list">
              <p>
                For those seeking admissions, an informal interaction will be conducted in which pupil and both the parents have to be present. The final decision of the admission committee will be binding.</p>
            </div>
          </li>

          <li>
            <a data-bs-toggle="collapse" data-bs-target="#faq2" class="collapsed">What is the fee structure? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq2" class="collapse" data-bs-parent=".faq-list">
              <p>
                Please call the school for fee details.</p>
            </div>
          </li>

          <li>
            <a data-bs-toggle="collapse" data-bs-target="#faq3" class="collapsed">Is there any entrance Exams? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq3" class="collapse" data-bs-parent=".faq-list">
              <p>
                Required testing depends on the age of the child applying to attend Excellent Tutorial. Once you have submitted an inquiry form, you will be able to access the Admissions Portal which includes a comprehensive list of all necessary testing and required forms.</p>
            </div>
          </li>

          <li>
            <a data-bs-toggle="collapse" data-bs-target="#faq4" class="collapsed">How do I locate a program that's right for me? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq4" class="collapse" data-bs-parent=".faq-list">
              <p>
                Search by degree level: Undergraduate Programs, Master's Degree Programs, Doctorate Degree Programs, Teacher Certification Programs, Other Certificate Programs, and Online Programs              </p>
            </div>
          </li>

          <li>
            <a data-bs-toggle="collapse" data-bs-target="#faq5" class="collapsed">How do I register for a required admission test and how will you get my scores? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq5" class="collapse" data-bs-parent=".faq-list">
              <p>
                The following links will direct you to information from Educational Testing Service about admission tests (which, may be required depending upon your specific program of interest). When taking a test, please be sure to indicate the relevant school code(s) so that we receive an official score report. Please note that none of our Master's Degree programs require the GRE for admission.               </p>
            </div>
          </li>

          <li>
            <a data-bs-toggle="collapse" data-bs-target="#faq6" class="collapsed">Is Online Mode available? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-x icon-close"></i></a>
            <div id="faq6" class="collapse" data-bs-parent=".faq-list">
              <p>
                Yes, We have both Online as well as offline batches.
              </p>
            </div>
          </li>

        </ul>

      </div>
    </section>
    <!-- End Frequently Asked Questions Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Our Talented Staff</h2>
          <p>We have the most amazing staff who are masters in their particular subject. They have completed their Degrre and some have done PhD.</p>
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="100">
              <div class="member-img">
                <img src="assets/img/team/team_1.avif" class="img-fluid" alt="">
                <div class="social">
                  <a href="https://twitter.com/"><i class="bi bi-twitter"></i></a>
                  <a href="https://www.linkedin.com/"><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Vikram Roy</h4>
                <span>Founder of Excellent Tutorials</span>
                <p>PhD in Mathematics</p>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="200">
              <div class="member-img">
                <img src="assets/img/team/team_2.avif" class="img-fluid" alt="">
                <div class="social">
                  <a href="https://twitter.com/"><i class="bi bi-twitter"></i></a>
                  <a href="https://www.linkedin.com/"><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Geeta Sharma</h4>
                <span>Co-Founder of Excellent Tutorials</span>
                <p>PhD in Statistics</p>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="300">
              <div class="member-img">
                <img src="assets/img/team/team_3.avif" class="img-fluid" alt="">
                <div class="social">
                  <a href="https://twitter.com/"><i class="bi bi-twitter"></i></a>
                  <a href="https://www.linkedin.com/"><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Danish Khan</h4>
                <span>Trustee</span>
                <p>PhD in Computer Science</p>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="400">
              <div class="member-img">
                <img src="assets/img/team/team_4.avif" class="img-fluid" alt="">
                <div class="social">
                  <a href="https://twitter.com/"><i class="bi bi-twitter"></i></a>
                  <a href="https://www.linkedin.com/"><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Alex Watson</h4>
                <span>Chairman</span>
                <p>PhD in Literature</p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
    <!-- End Team Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-6">

            <div class="row">
              <div class="col-md-12">
                <div class="info-box">
                  <i class="bx bx-map"></i>
                  <h3>Our Address</h3>
                  <p>Bharati Bhavan, Rajwada Chowk, Sangli, Maharashtra 416416</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4">
                  <i class="bx bx-envelope"></i>
                  <h3>Email Us</h3>
                  <p>iimrda@bharatividyapeeth.edu</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4">
                  <i class="bx bx-phone-call"></i>
                  <h3>Call Us</h3>
                  <p>0233 232 5776</p>
                </div>
              </div>
            </div>

          </div>

          <div class="col-lg-6">
            <form id="Contact_DB"  method="post" role="form" class="php-email-form">
              <h5 class="text-center">Let's Talk With Our Educator</h5>
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>

                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email">
                </div>

              </div>

              <div class="form-group mt-3">
                <input type="number" class="form-control" name="mob_number" id="mob_number" placeholder="Your Mobile Number" required>
              </div>

              <div class="form-group mt-3">
                <textarea class="form-control" name="message" id="message" rows="5" placeholder="Message" required></textarea>
              </div>

              <input type="hidden" name="Contact_Client_Name" id="Contact_Client_Name" value="Excellent Tutorials">
              <input type="hidden" name="e_card_id" id="e_card_id" value="1">
                
              <div class="text-center">
                <button type="submit">Send Message</button>
              </div>

            </form>
          </div>

        </div>

      </div>
    </section>
    <!-- End Contact Section -->

  </main>
  <!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6 footer-contact">
            <img src="<?php echo base_url('assets/img/excellent_tutorials_logo.png');?>" alt="Excellent tutorials logo" height="120px" width="50%">
            <p>
              <i class="bi bi-geo-alt"></i>
              Bharati Bhavan,<br>
              Rajwada Chowk, Sangli,<br>
              Maharashtra, 416416. <br><br>
              <i class="bi bi-phone"></i>
              <strong>Phone:</strong> 0233 232 5776<br>
              <i class="bi bi-envelope"></i>
              <strong>Email:</strong> imrda@bharatividyapeeth.edu<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#about">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-5 col-md-6 footer-newsletter">
            <h4>Join Our Newsletter</h4>
            <p>Subscribe to get Notification</p>
            <form id="Newsletter_DB" method="post">
              <input type="email" name="Subscribe_Email" id="Subscribe_Email" >
              <input type="hidden" name="Subscribe_Client_Name" id="Subscribe_Client_Name" value="Excellent Tutorials">
              <input type="button" value="Subscribe" style="background-color:#d09d1b; color:white; border:none; padding:8px;" name="Newsletter_DB_Btn" id="Newsletter_DB_Btn">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>Excellent Tutorials</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          Designed by <a href="#" style="color:#d09d1b;">Samiya Panhalkar</a>
        </div>
      </div>
      <div class="social-links text-center text-md-end pt-3 pt-md-0">
        <a href="https://twitter.com/" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="https://www.facebook.com/" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="https://www.linkedin.com/" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer>
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url('assets/js/jquery-3.6.0.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/purecounter/purecounter.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/aos/aos.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/glightbox/js/glightbox.min.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/isotope-layout/isotope.pkgd.min.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/swiper/swiper-bundle.min.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/php-email-form/validate.js');?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url('assets/js/main.js');?>"></script>
  <script src="<?php echo base_url('assets/js/MyLib.js');?>"></script>
  
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>

</html>