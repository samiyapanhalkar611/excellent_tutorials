<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Kolkata');

class Education extends CI_Controller {
    public function __construct(){
			parent::__construct();
			// Your own constructor code
        }
    public function index(){
        
        $this->load->view('index');

    }
    public function Contact_Data_DB_Save_(){
        $contactData = array(
            'Contact_name' => (!empty($this->input->post('Contact_name')))?($this->input->post('Contact_name')):(''),
            'Contact_Email' => (!empty($this->input->post('Contact_Email')))?($this->input->post('Contact_Email')):(''),
            'Contact_Mobile' => (!empty($this->input->post('Contact_Mobile')))?($this->input->post('Contact_Mobile')):(''),
            'Contact_Message' =>(!empty($this->input->post('Contact_Message')))?($this->input->post('Contact_Message')):(''),
            'Contact_Client_Name' =>(!empty($this->input->post('Contact_Client_Name')))?($this->input->post('Contact_Client_Name')):(''),
            'e_card_id' => (!empty($this->input->post('e_card_id')))?($this->input->post('e_card_id')):(''),
            'Created_Date'=>date('Y-m-d H:i:s'),
            'status'=>1
        );

        $insertContact = $this->EDTR->Contact_Data_Save($contactData);

        if(!empty($insertContact)){
            $msg="Your Information submitted Successfully!";
        }else{
            $msg="Something Went Wrong...Try Again..!";
        }
        echo json_encode($msg);
    }

    public function Newsletter_Data_DB_Save(){
        $newsletterData = array(    
            "Subscribe_Email" =>(!empty($this->input->post("Subscribe_Email")))?($this->input->post("Subscribe_Email")):(''),
            "Subscribe_Date" => date("Y-m-d H:i:s"),
            "Subscribe_Client" =>(!empty($this->input->post("Subscribe_Client")))?($this->input->post("Subscribe_Client")):(''),
            "status" =>1,
        );           
       
        $insertNewsletterData = $this->EDTR->Newsletter_Data_Save($newsletterData);

        if(!empty($insertNewsletterData)){
            $msg="Your Information submitted Successfully!";
        }else{
            $msg="Something Went Wrong...Try Again..!";
        }
        echo json_encode($msg);
    
    }

    public function admission_view()
	{
        $this->form_validation->set_rules('studentFname', 'student First name', 'trim|required');
        $this->form_validation->set_rules('studentLname', 'student Last name', 'trim|required');
        $this->form_validation->set_rules('studentDob', 'Date of birth', 'trim|required');
        $this->form_validation->set_rules('parentName', 'Parent Name', 'trim|required');
        $this->form_validation->set_rules('className', 'class Name', 'trim|required');
        $this->form_validation->set_rules('address', 'Address', 'trim|required');
        $this->form_validation->set_rules('city', 'city', 'trim|required');
        $this->form_validation->set_rules('state', 'state', 'trim|required');
        $this->form_validation->set_rules('pin', 'Pin', 'trim|required');
        $this->form_validation->set_rules('country', 'country', 'trim|required');
        $this->form_validation->set_rules('mobile', 'mobile number', 'trim|required');
        $this->form_validation->set_rules('email', 'email id', 'trim|required');
        $this->form_validation->set_rules('transportService', 'transport Service', 'trim|required');
        
        if ($this->form_validation->run() == FALSE){
            $this->load->view('admissionPage');
        }
        else{
                $data=array(
                "studentFname"=>(!empty($this->input->post('studentFname')))?($this->input->post('studentFname')):(''),
                "studentLname"=>(!empty($this->input->post('studentLname')))?($this->input->post('studentLname')):(''),
                "studentDob"=>(!empty($this->input->post('studentDob')))?($this->input->post('studentDob')):(''),
                "parentName"=>(!empty($this->input->post('parentName')))?($this->input->post('parentName')):(''),
                "className"=>(!empty($this->input->post('className')))?($this->input->post('className')):(''),
                "address"=>(!empty($this->input->post('address')))?($this->input->post('address')):(''),
                "city"=>(!empty($this->input->post('city')))?($this->input->post('city')):(''),
                "state"=>(!empty($this->input->post('state')))?($this->input->post('state')):(''),
                "pin"=>(!empty($this->input->post('pin')))?($this->input->post('pin')):(''),
                "country"=>(!empty($this->input->post('country')))?($this->input->post('country')):(''),
                "mobile"=>(!empty($this->input->post('mobile')))?($this->input->post('mobile')):(''),
                "email"=>(!empty($this->input->post('email')))?($this->input->post('email')):(''),
                "transportService"=>(!empty($this->input->post('transportService')))?($this->input->post('transportService')):(''),


            );  

            if($this->EDTR->DB_Admission_Data($data)) {
                $this->session->set_flashdata('success','Your information submitted successfully...!');
                redirect(base_url('Admission_Data_Save'));
            } else {
                $this->session->set_flashdata('error', 'Oops..Something Went Wrong..Please Try Again!');
                redirect(base_url('Admission_Data_Save'));
            }
        }			
	}

}
?>