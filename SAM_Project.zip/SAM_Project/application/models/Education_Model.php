<?php
class Education_Model extends CI_Model {
    
    public function __construct(){
        parent::__construct();
        $this->load->database();
    }

    public function Contact_Data_Save($contactData)
    {
        $this->db->insert('tbl_contact_details_clients', $contactData);
        return $insert_id = $this->db->insert_id();  
    }

    public function Newsletter_Data_Save($newsletterData){
        $this->db->insert('tbl_subscribe_db_data',$newsletterData);
        return $insert_id = $this->db->insert_id();
    }

    function DB_Admission_Data($data)
    {
        $this->db->insert('Tbl_admission_data',$data);
        return $insert_id = $this->db->insert_id();
    }

}
?>