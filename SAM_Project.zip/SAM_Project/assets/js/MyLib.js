var base_url=$('#base_url').val();

  //$("#Newsletter_DB").submit(function(event){
    $("#Newsletter_DB_Btn").click(function(event){
        if($('#Subscribe_Email').val()==''){
            swal("Email Required!","error");    
        }else{
            $.ajax({
                type: "POST",
                url: base_url+"Newsletter_DB_Save",
                data: {
                    "Subscribe_Email":$('#Subscribe_Email').val(),
                    "Subscribe_Client":$('#Subscribe_Client_Name').val(),
                 },
                dataType: "json",
        
                success: function (response) {
                    $('#Newsletter_DB')[0].reset();
                    swal("Thank You!",response,"success");
                }
            });
        }
     
  });

$("#Contact_DB").submit(function(event){
 
    $.ajax({
        type: "POST",
        url: base_url+"Contact_DB_Save",
        data: {
            "Contact_name": $('#name').val(),
            "Contact_Email":$('#email').val(),
            "Contact_Mobile":$('#mob_number').val(), 
            "Contact_Message":$('#message').val(), 
            "Contact_Client_Name":$('#Contact_Client_Name').val(), 
            "e_card_id":$('#e_card_id').val()
            },

        dataType: "json",

        success: function (response) {
            $('#Contact_DB')[0].reset();
            swal("Thank You!",response,"success");
        }
    });
});